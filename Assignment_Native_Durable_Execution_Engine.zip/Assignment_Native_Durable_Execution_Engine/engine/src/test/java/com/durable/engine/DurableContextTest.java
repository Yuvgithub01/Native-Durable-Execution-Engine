package com.durable.engine;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class DurableContextTest {
    @Test
    void memoizesCompletedStepAcrossReruns(@TempDir Path tempDir) throws Exception {
        Path db = tempDir.resolve("memoize.db");
        AtomicInteger calls = new AtomicInteger();

        DurableWorkflow<String> workflow = context -> context.step("create-user", () -> {
            calls.incrementAndGet();
            return "done";
        });

        try (WorkflowRunner runner = new WorkflowRunner(new SQLiteWorkflowStore(db), Duration.ofSeconds(2))) {
            assertEquals("done", runner.run("wf-memoize", workflow));
            assertEquals("done", runner.run("wf-memoize", workflow));
        }

        assertEquals(1, calls.get());
    }

    @Test
    void rerunsFailedStepButSkipsCompletedStep(@TempDir Path tempDir) throws Exception {
        Path db = tempDir.resolve("failure.db");
        AtomicInteger stableCalls = new AtomicInteger();
        AtomicInteger flakyCalls = new AtomicInteger();
        AtomicBoolean firstAttempt = new AtomicBoolean(true);

        DurableWorkflow<String> workflow = context -> {
            context.step("stable-step", () -> {
                stableCalls.incrementAndGet();
                return "stable";
            });
            return context.step("flaky-step", () -> {
                flakyCalls.incrementAndGet();
                if (firstAttempt.getAndSet(false)) {
                    throw new IllegalStateException("simulated failure");
                }
                return "recovered";
            });
        };

        try (WorkflowRunner runner = new WorkflowRunner(new SQLiteWorkflowStore(db), Duration.ofSeconds(2))) {
            assertThrows(IllegalStateException.class, () -> runner.run("wf-failure", workflow));
            assertEquals("recovered", runner.run("wf-failure", workflow));
        }

        assertEquals(1, stableCalls.get(), "Completed step should not run again");
        assertEquals(2, flakyCalls.get(), "Failed step should rerun");
    }

    @Test
    void reclaimsZombieInProgressStepAfterLeaseExpiry(@TempDir Path tempDir) throws Exception {
        Path db = tempDir.resolve("zombie.db");

        try (SQLiteWorkflowStore store = new SQLiteWorkflowStore(db)) {
            // Initialize schema.
        }

        long now = System.currentTimeMillis();
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:" + db.toAbsolutePath());
             PreparedStatement statement = connection.prepareStatement("""
                     INSERT INTO steps(workflow_id, step_key, status, lease_owner, lease_expires_at, updated_at)
                     VALUES(?, ?, 'IN_PROGRESS', ?, ?, ?)
                     """)) {
            statement.setString(1, "wf-zombie");
            statement.setString(2, "create-record#1");
            statement.setString(3, "stale-worker");
            statement.setLong(4, now - 5_000L);
            statement.setLong(5, now - 5_000L);
            statement.executeUpdate();
        }

        DurableWorkflow<String> workflow = context -> context.step("create-record", () -> "reclaimed");
        try (WorkflowRunner runner = new WorkflowRunner(new SQLiteWorkflowStore(db), Duration.ofSeconds(2))) {
            String result = runner.run("wf-zombie", workflow);
            assertEquals("reclaimed", result);
        }
    }

    @Test
    void supportsParallelStepsWithThreadSafePersistence(@TempDir Path tempDir) throws Exception {
        Path db = tempDir.resolve("parallel.db");

        DurableWorkflow<String> workflow = context -> {
            String employeeId = context.step("create-record", () -> "emp-001");
            ExecutorService pool = Executors.newFixedThreadPool(2);
            try {
                CompletableFuture<String> laptop = CompletableFuture.supplyAsync(
                        stepSupplier(context, "provision-laptop", () -> "laptop-for-" + employeeId),
                        pool
                );
                CompletableFuture<String> access = CompletableFuture.supplyAsync(
                        stepSupplier(context, "provision-access", () -> "access-for-" + employeeId),
                        pool
                );
                return laptop.join() + "|" + access.join();
            } finally {
                pool.shutdownNow();
            }
        };

        try (WorkflowRunner runner = new WorkflowRunner(new SQLiteWorkflowStore(db), Duration.ofSeconds(2))) {
            String result = runner.run("wf-parallel", workflow);
            assertTrue(result.contains("laptop-for-emp-001"));
            assertTrue(result.contains("access-for-emp-001"));
        }
    }

    @Test
    void autoIdStepSupportsLoopedCallsWithoutManualIds(@TempDir Path tempDir) throws Exception {
        Path db = tempDir.resolve("auto-step.db");
        AtomicInteger sideEffects = new AtomicInteger();

        DurableWorkflow<Integer> workflow = context -> {
            int total = 0;
            for (int i = 0; i < 3; i++) {
                total += context.step(() -> sideEffects.incrementAndGet());
            }
            return total;
        };

        try (WorkflowRunner runner = new WorkflowRunner(new SQLiteWorkflowStore(db), Duration.ofSeconds(2))) {
            assertEquals(6, runner.run("wf-auto", workflow));
            assertEquals(6, runner.run("wf-auto", workflow));
        }

        assertEquals(3, sideEffects.get(), "Auto-ID steps should be memoized on rerun");
    }

    private static <T> Supplier<T> stepSupplier(DurableContext context, String id, ThrowingSupplier<T> supplier) {
        return () -> {
            try {
                return context.step(id, supplier::get);
            } catch (Exception ex) {
                throw new CompletionException(ex);
            }
        };
    }

    @FunctionalInterface
    private interface ThrowingSupplier<T> {
        T get() throws Exception;
    }
}
