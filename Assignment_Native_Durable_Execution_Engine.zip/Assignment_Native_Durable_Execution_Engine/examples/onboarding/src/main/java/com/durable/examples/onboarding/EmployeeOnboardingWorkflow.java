package com.durable.examples.onboarding;

import com.durable.engine.DurableContext;
import com.durable.engine.DurableWorkflow;

import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.Executor;

public final class EmployeeOnboardingWorkflow implements DurableWorkflow<String> {
    private final String candidateName;
    private final OnboardingSystems onboardingSystems;
    private final CrashController crashController;
    private final Executor executor;

    public EmployeeOnboardingWorkflow(
            String candidateName,
            OnboardingSystems onboardingSystems,
            CrashController crashController,
            Executor executor
    ) {
        this.candidateName = Objects.requireNonNull(candidateName, "candidateName");
        this.onboardingSystems = Objects.requireNonNull(onboardingSystems, "onboardingSystems");
        this.crashController = Objects.requireNonNull(crashController, "crashController");
        this.executor = Objects.requireNonNull(executor, "executor");
    }

    @Override
    public String run(DurableContext context) throws Exception {
        // Step 1: Sequential
        String employeeId = context.step("create-record", () ->
                onboardingSystems.createEmployeeRecord(candidateName, crashController)
        );

        // Step 2 + 3: Parallel
        CompletableFuture<String> laptopFuture = CompletableFuture.supplyAsync(() ->
                callDurableStep(context, "provision-laptop", () ->
                        onboardingSystems.provisionLaptop(employeeId, crashController)
                ), executor);

        CompletableFuture<String> accessFuture = CompletableFuture.supplyAsync(() ->
                callDurableStep(context, "provision-access", () ->
                        onboardingSystems.provisionAccess(employeeId, crashController)
                ), executor);

        String laptopAsset = join(laptopFuture);
        String accessGrant = join(accessFuture);

        // Step 4: Sequential
        return context.step("send-welcome-email", () ->
                onboardingSystems.sendWelcomeEmail(employeeId, laptopAsset, accessGrant, crashController)
        );
    }

    private static <T> T callDurableStep(DurableContext context, String stepId, ThrowingSupplier<T> supplier) {
        try {
            return context.step(stepId, supplier::get);
        } catch (Exception ex) {
            throw new CompletionException(ex);
        }
    }

    private static <T> T join(CompletableFuture<T> future) {
        try {
            return future.join();
        } catch (CompletionException ex) {
            Throwable cause = ex.getCause();
            if (cause instanceof RuntimeException runtimeException) {
                throw runtimeException;
            }
            throw ex;
        }
    }

    @FunctionalInterface
    private interface ThrowingSupplier<T> {
        T get() throws Exception;
    }
}
