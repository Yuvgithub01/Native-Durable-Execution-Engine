package com.durable.engine;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.time.Duration;
import java.util.Objects;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

public final class DurableContext {
    private static final long DEFAULT_POLL_MILLIS = 100L;

    private final String workflowId;
    private final String runOwnerId;
    private final WorkflowStore store;
    private final long leaseMillis;
    private final ValueSerializer serializer;
    private final ConcurrentHashMap<String, AtomicLong> explicitStepCounters = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, AtomicLong> automaticStepCounters = new ConcurrentHashMap<>();

    DurableContext(String workflowId, String runOwnerId, WorkflowStore store, Duration leaseDuration) {
        this.workflowId = Objects.requireNonNull(workflowId, "workflowId");
        this.runOwnerId = Objects.requireNonNull(runOwnerId, "runOwnerId");
        this.store = Objects.requireNonNull(store, "store");
        this.leaseMillis = leaseDuration.toMillis();
        this.serializer = new ValueSerializer();
    }

    public String workflowId() {
        return workflowId;
    }

    public <T> T step(String id, Callable<T> fn) throws Exception {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(fn, "fn");

        String normalizedId = normalizeStepId(id);
        long sequence = explicitStepCounters.computeIfAbsent(normalizedId, ignored -> new AtomicLong()).incrementAndGet();
        String stepKey = normalizedId + "#" + sequence;
        return executeDurableStep(stepKey, fn);
    }

    public <T> T step(Callable<T> fn) throws Exception {
        Objects.requireNonNull(fn, "fn");

        String callsite = callerIdentity();
        long sequence = automaticStepCounters.computeIfAbsent(callsite, ignored -> new AtomicLong()).incrementAndGet();
        String stepKey = "auto:" + callsite + "#" + sequence;
        return executeDurableStep(stepKey, fn);
    }

    public <T> CompletableFuture<T> stepAsync(String id, Callable<T> fn, Executor executor) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                return step(id, fn);
            } catch (Exception ex) {
                throw new IllegalStateException("Async step failed: " + id, ex);
            }
        }, executor);
    }

    @SuppressWarnings("unchecked")
    private <T> T executeDurableStep(String stepKey, Callable<T> fn) throws Exception {
        while (true) {
            long now = System.currentTimeMillis();
            long leaseExpiresAt = now + leaseMillis;
            StepRecord existing = store.findStep(workflowId, stepKey).orElse(null);

            if (existing == null) {
                boolean inserted = store.insertInProgress(workflowId, stepKey, runOwnerId, leaseExpiresAt, now);
                if (inserted) {
                    return runAndPersist(stepKey, fn);
                }
                continue;
            }

            switch (existing.status()) {
                case COMPLETED -> {
                    Object cached = serializer.deserialize(existing.outputType(), existing.outputJson());
                    return (T) cached;
                }
                case FAILED -> {
                    boolean claimed = store.claimFailedStep(workflowId, stepKey, runOwnerId, leaseExpiresAt, now);
                    if (claimed) {
                        return runAndPersist(stepKey, fn);
                    }
                }
                case IN_PROGRESS -> {
                    if (existing.leaseExpired(now)) {
                        boolean stolen = store.stealExpiredInProgress(
                                workflowId,
                                stepKey,
                                runOwnerId,
                                leaseExpiresAt,
                                now
                        );
                        if (stolen) {
                            return runAndPersist(stepKey, fn);
                        }
                    } else {
                        waitForLeaseRefresh(existing.leaseExpiresAt(), now);
                    }
                }
                default -> throw new IllegalStateException("Unknown step status for " + stepKey + ": " + existing.status());
            }
        }
    }

    private <T> T runAndPersist(String stepKey, Callable<T> fn) throws Exception {
        try {
            T value = fn.call();
            SerializedValue serialized = serializer.serialize(value);
            store.markCompleted(
                    workflowId,
                    stepKey,
                    runOwnerId,
                    serialized.typeName(),
                    serialized.jsonValue(),
                    System.currentTimeMillis()
            );
            return value;
        } catch (Exception ex) {
            failSafely(stepKey, ex);
            throw ex;
        } catch (Error error) {
            failSafely(stepKey, error);
            throw error;
        }
    }

    private void failSafely(String stepKey, Throwable failure) {
        try {
            store.markFailed(
                    workflowId,
                    stepKey,
                    runOwnerId,
                    stackTraceAsString(failure),
                    System.currentTimeMillis()
            );
        } catch (Exception markFailureEx) {
            throw new IllegalStateException("Failed to persist FAILED status for step " + stepKey, markFailureEx);
        }
    }

    private static String normalizeStepId(String id) {
        String normalized = id.trim();
        if (normalized.isEmpty()) {
            throw new IllegalArgumentException("step id must not be blank");
        }
        return normalized;
    }

    private static String callerIdentity() {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        for (StackTraceElement element : stackTrace) {
            String className = element.getClassName();
            if (className.equals(Thread.class.getName())) {
                continue;
            }
            if (className.equals(DurableContext.class.getName())) {
                continue;
            }
            return className + "#" + element.getMethodName() + ":" + element.getLineNumber();
        }
        return "unknown-callsite";
    }

    private static String stackTraceAsString(Throwable throwable) {
        StringWriter buffer = new StringWriter();
        throwable.printStackTrace(new PrintWriter(buffer));
        return buffer.toString();
    }

    private static void waitForLeaseRefresh(Long leaseExpiresAt, long now) {
        long waitMillis = (leaseExpiresAt == null)
                ? DEFAULT_POLL_MILLIS
                : Math.max(1L, Math.min(DEFAULT_POLL_MILLIS, leaseExpiresAt - now));
        try {
            TimeUnit.MILLISECONDS.sleep(waitMillis);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Interrupted while waiting for active step lease", ex);
        }
    }
}
