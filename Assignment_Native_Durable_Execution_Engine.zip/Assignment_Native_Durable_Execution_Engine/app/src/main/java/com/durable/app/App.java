package com.durable.app;

import com.durable.engine.SQLiteWorkflowStore;
import com.durable.engine.WorkflowRunner;
import com.durable.examples.onboarding.CrashController;
import com.durable.examples.onboarding.EmployeeOnboardingWorkflow;
import com.durable.examples.onboarding.OnboardingSystems;
import com.durable.examples.onboarding.SimulatedCrashException;

import java.nio.file.Path;
import java.time.Duration;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public final class App {
    private App() {
    }

    public static void main(String[] args) throws Exception {
        CliOptions options = CliOptions.parse(args);
        ExecutorService executor = Executors.newFixedThreadPool(4);

        try {
            OnboardingSystems systems = new OnboardingSystems(options.stateDir);
            EmployeeOnboardingWorkflow workflow = new EmployeeOnboardingWorkflow(
                    options.candidateName,
                    systems,
                    new CrashController(options.crashStepId, options.hardCrash),
                    executor
            );

            try (WorkflowRunner runner = new WorkflowRunner(
                    new SQLiteWorkflowStore(options.dbPath),
                    Duration.ofMillis(options.leaseMillis)
            )) {
                String result = runner.run(options.workflowId, workflow);
                System.out.println("Workflow completed successfully.");
                System.out.println("Result: " + result);
                System.out.println("Workflow ID: " + options.workflowId);
                System.out.println("State directory: " + options.stateDir.toAbsolutePath());
                System.out.println("DB path: " + options.dbPath.toAbsolutePath());
            }
        } catch (SimulatedCrashException ex) {
            System.err.println(ex.getMessage());
            System.err.println("Restart with the same --workflow-id to resume.");
            System.exit(2);
        } finally {
            executor.shutdown();
            executor.awaitTermination(3, TimeUnit.SECONDS);
        }
    }

    private static final class CliOptions {
        private final Path dbPath;
        private final Path stateDir;
        private final String workflowId;
        private final String candidateName;
        private final String crashStepId;
        private final boolean hardCrash;
        private final long leaseMillis;

        private CliOptions(
                Path dbPath,
                Path stateDir,
                String workflowId,
                String candidateName,
                String crashStepId,
                boolean hardCrash,
                long leaseMillis
        ) {
            this.dbPath = dbPath;
            this.stateDir = stateDir;
            this.workflowId = workflowId;
            this.candidateName = candidateName;
            this.crashStepId = crashStepId;
            this.hardCrash = hardCrash;
            this.leaseMillis = leaseMillis;
        }

        static CliOptions parse(String[] args) {
            Map<String, String> options = parseFlags(args);
            boolean hardCrash = options.containsKey("--hard-crash");

            Path dbPath = Path.of(options.getOrDefault("--db", "build/workflow.db"));
            Path stateDir = Path.of(options.getOrDefault("--state-dir", "build/onboarding-state"));
            String workflowId = options.getOrDefault("--workflow-id", "onboarding-demo");
            String candidateName = options.getOrDefault("--candidate", "Alice");
            String crashStep = options.get("--crash-step");
            long leaseMillis = Long.parseLong(options.getOrDefault("--lease-ms", "3000"));

            if (workflowId.isBlank()) {
                throw new IllegalArgumentException("--workflow-id must not be blank");
            }
            if (candidateName.isBlank()) {
                throw new IllegalArgumentException("--candidate must not be blank");
            }
            if (leaseMillis <= 0) {
                throw new IllegalArgumentException("--lease-ms must be > 0");
            }
            return new CliOptions(dbPath, stateDir, workflowId.trim(), candidateName.trim(), crashStep, hardCrash, leaseMillis);
        }

        private static Map<String, String> parseFlags(String[] args) {
            if (Arrays.asList(args).contains("--help")) {
                printUsageAndExit();
            }

            Map<String, String> options = new HashMap<>();
            for (int i = 0; i < args.length; i++) {
                String arg = args[i];
                if ("--hard-crash".equals(arg)) {
                    options.put(arg, "true");
                    continue;
                }

                if (!arg.startsWith("--")) {
                    throw new IllegalArgumentException("Unknown argument: " + arg);
                }
                if (i + 1 >= args.length) {
                    throw new IllegalArgumentException("Missing value for argument: " + arg);
                }
                options.put(arg, args[++i]);
            }
            return options;
        }

        private static void printUsageAndExit() {
            String usage = """
                    Usage:
                      mvn -pl app -am exec:java -Dexec.args="--workflow-id wf-1 [options]"

                    Options:
                      --workflow-id <id>     Workflow instance ID used for resume semantics.
                      --candidate <name>     Candidate name for onboarding workflow. Default: Alice
                      --db <path>            SQLite DB path. Default: build/workflow.db
                      --state-dir <path>     Side-effect simulation directory. Default: build/onboarding-state
                      --crash-step <step>    Simulate crash at step (create-record | provision-laptop | provision-access | send-welcome-email)
                      --hard-crash           Kill process using Runtime.halt after side-effect.
                      --lease-ms <millis>    Lease duration for IN_PROGRESS records. Default: 3000
                    """;
            System.out.println(usage);
            System.exit(0);
        }
    }
}
