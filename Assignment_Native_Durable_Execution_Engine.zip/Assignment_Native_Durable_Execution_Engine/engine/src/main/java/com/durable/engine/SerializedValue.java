package com.durable.engine;

record SerializedValue(String typeName, String jsonValue) {
}
