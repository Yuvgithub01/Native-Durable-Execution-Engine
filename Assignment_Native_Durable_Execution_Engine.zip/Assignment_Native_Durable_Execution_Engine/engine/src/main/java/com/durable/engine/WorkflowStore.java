package com.durable.engine;

import java.util.Optional;

public interface WorkflowStore extends AutoCloseable {
    Optional<StepRecord> findStep(String workflowId, String stepKey);

    boolean insertInProgress(String workflowId, String stepKey, String leaseOwner, long leaseExpiresAt, long nowMillis);

    boolean stealExpiredInProgress(
            String workflowId,
            String stepKey,
            String newLeaseOwner,
            long newLeaseExpiresAt,
            long nowMillis
    );

    boolean claimFailedStep(String workflowId, String stepKey, String leaseOwner, long leaseExpiresAt, long nowMillis);

    void markCompleted(
            String workflowId,
            String stepKey,
            String leaseOwner,
            String outputType,
            String outputJson,
            long nowMillis
    );

    void markFailed(String workflowId, String stepKey, String leaseOwner, String errorMessage, long nowMillis);

    @Override
    default void close() {
    }
}
