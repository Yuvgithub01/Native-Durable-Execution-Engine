package com.durable.engine;

public enum StepStatus {
    IN_PROGRESS,
    COMPLETED,
    FAILED
}
