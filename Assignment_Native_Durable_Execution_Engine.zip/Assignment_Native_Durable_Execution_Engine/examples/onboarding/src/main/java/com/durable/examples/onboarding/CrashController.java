package com.durable.examples.onboarding;

import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;

public final class CrashController {
    private final String crashStepId;
    private final boolean hardCrash;
    private final AtomicBoolean triggered = new AtomicBoolean(false);

    public CrashController(String crashStepId, boolean hardCrash) {
        this.crashStepId = crashStepId;
        this.hardCrash = hardCrash;
    }

    public void maybeCrash(String stepId) {
        if (crashStepId == null || crashStepId.isBlank()) {
            return;
        }
        if (!Objects.equals(crashStepId, stepId)) {
            return;
        }
        if (!triggered.compareAndSet(false, true)) {
            return;
        }

        if (hardCrash) {
            Runtime.getRuntime().halt(137);
        }
        throw new SimulatedCrashException("Simulated crash at step: " + stepId);
    }
}
