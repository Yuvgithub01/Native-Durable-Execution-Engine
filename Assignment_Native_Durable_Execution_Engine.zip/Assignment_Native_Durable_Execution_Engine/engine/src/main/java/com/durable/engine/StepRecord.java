package com.durable.engine;

public record StepRecord(
        String workflowId,
        String stepKey,
        StepStatus status,
        String outputType,
        String outputJson,
        String errorMessage,
        String leaseOwner,
        Long leaseExpiresAt,
        long updatedAt
) {
    public boolean leaseExpired(long nowMillis) {
        return leaseExpiresAt != null && leaseExpiresAt < nowMillis;
    }
}
