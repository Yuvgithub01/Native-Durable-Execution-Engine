package com.durable.engine;

import java.time.Duration;
import java.util.Objects;
import java.util.UUID;

public final class WorkflowRunner implements AutoCloseable {
    private static final Duration DEFAULT_LEASE_DURATION = Duration.ofSeconds(3);

    private final WorkflowStore workflowStore;
    private final Duration leaseDuration;

    public WorkflowRunner(WorkflowStore workflowStore) {
        this(workflowStore, DEFAULT_LEASE_DURATION);
    }

    public WorkflowRunner(WorkflowStore workflowStore, Duration leaseDuration) {
        this.workflowStore = Objects.requireNonNull(workflowStore, "workflowStore");
        this.leaseDuration = Objects.requireNonNull(leaseDuration, "leaseDuration");
        if (leaseDuration.isZero() || leaseDuration.isNegative()) {
            throw new IllegalArgumentException("leaseDuration must be positive");
        }
    }

    public <T> T run(String workflowId, DurableWorkflow<T> workflow) throws Exception {
        Objects.requireNonNull(workflowId, "workflowId");
        Objects.requireNonNull(workflow, "workflow");
        if (workflowId.isBlank()) {
            throw new IllegalArgumentException("workflowId must not be blank");
        }

        DurableContext context = new DurableContext(
                workflowId.trim(),
                UUID.randomUUID().toString(),
                workflowStore,
                leaseDuration
        );
        return workflow.run(context);
    }

    @Override
    public void close() {
        workflowStore.close();
    }
}
