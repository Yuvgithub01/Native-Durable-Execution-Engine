package com.durable.examples.onboarding;

import com.durable.engine.SQLiteWorkflowStore;
import com.durable.engine.WorkflowRunner;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.time.Duration;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class EmployeeOnboardingWorkflowTest {
    @Test
    void resumesAfterCrashWithoutReexecutingCompletedSteps(@TempDir Path tempDir) throws Exception {
        Path dbPath = tempDir.resolve("onboarding.db");
        Path sideEffectDir = tempDir.resolve("side-effects");
        OnboardingSystems systems = new OnboardingSystems(sideEffectDir);

        ExecutorService firstExecutor = Executors.newFixedThreadPool(2);
        try (WorkflowRunner firstRun = new WorkflowRunner(
                new SQLiteWorkflowStore(dbPath),
                Duration.ofSeconds(2)
        )) {
            EmployeeOnboardingWorkflow crashingWorkflow = new EmployeeOnboardingWorkflow(
                    "Alice",
                    systems,
                    new CrashController("provision-laptop", false),
                    firstExecutor
            );
            assertThrows(SimulatedCrashException.class, () -> firstRun.run("wf-onboarding", crashingWorkflow));
        } finally {
            firstExecutor.shutdownNow();
        }

        ExecutorService secondExecutor = Executors.newFixedThreadPool(2);
        String result;
        try (WorkflowRunner secondRun = new WorkflowRunner(
                new SQLiteWorkflowStore(dbPath),
                Duration.ofSeconds(2)
        )) {
            EmployeeOnboardingWorkflow resumeWorkflow = new EmployeeOnboardingWorkflow(
                    "Alice",
                    systems,
                    new CrashController(null, false),
                    secondExecutor
            );
            result = secondRun.run("wf-onboarding", resumeWorkflow);
        } finally {
            secondExecutor.shutdownNow();
        }

        assertTrue(result.startsWith("welcome-sent-emp-alice-001"));
        assertEquals(1L, systems.countAuditEvents("SIDE_EFFECT:create-record-alice"));
        assertEquals(1L, systems.countAuditEvents("SIDE_EFFECT:provision-laptop-emp-alice-001"));
        assertEquals(1L, systems.countAuditEvents("SIDE_EFFECT:send-welcome-email-emp-alice-001"));
    }
}
