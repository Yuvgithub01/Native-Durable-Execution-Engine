# Native Durable Execution Engine (Assignment 1)

This repository now contains a Java 21 implementation of a durable workflow execution engine with SQLite-backed memoization and restart/resume behavior.

## Repository Layout

```text
.
|-- pom.xml                          # Maven parent (multi-module)
|-- engine/                          # Core durable execution library
|-- examples/
|   |-- onboarding/                  # Employee onboarding sample workflow
|-- app/                             # CLI runner
`-- Prompts.txt                      # AI prompt log used for implementation
```

## What Is Implemented

- Durable `step` primitive: `<T> T step(String id, Callable<T> fn)`
- Bonus auto-id step primitive: `<T> T step(Callable<T> fn)`
- SQLite `steps` table for persisted step status and outputs
- Memoization on restart: completed steps are returned from DB and not re-executed
- Failure semantics: failed steps are retried on the next workflow run, completed ones are skipped
- Parallel step support via `CompletableFuture` with thread-safe SQLite write handling
- Zombie step recovery: stale `IN_PROGRESS` lease is reclaimed and re-executed
- CLI crash simulation at a specific step (soft exception crash or hard process halt)

## Build and Test

```bash
mvn test
```

## Run Onboarding Workflow

Run normally:

```bash
mvn -pl app -am exec:java -Dexec.args="--workflow-id wf-1 --candidate Alice"
```

Simulate a crash at a specific step:

```bash
mvn -pl app -am exec:java -Dexec.args="--workflow-id wf-1 --candidate Alice --crash-step provision-laptop"
```

Resume after crash (same workflow ID):

```bash
mvn -pl app -am exec:java -Dexec.args="--workflow-id wf-1 --candidate Alice"
```

Hard crash (kills process and leaves stale `IN_PROGRESS`):

```bash
mvn -pl app -am exec:java -Dexec.args="--workflow-id wf-2 --candidate Alice --crash-step provision-laptop --hard-crash"
```

## Architecture

1. `WorkflowRunner` starts/resumes a workflow by creating a `DurableContext`.
2. `DurableContext.step(...)` computes a deterministic step key and consults `WorkflowStore`.
3. `SQLiteWorkflowStore` persists and reads rows in `steps`:
   - `IN_PROGRESS`
   - `COMPLETED`
   - `FAILED`
4. If a step is `COMPLETED`, cached output is deserialized and returned.
5. If a step is `FAILED`, it is claimed and re-executed.
6. If a step is stale `IN_PROGRESS` (lease expired), it is reclaimed (zombie recovery).

## Sequence Tracking (Loops and Conditionals)

- For explicit IDs: step key format is `<step-id>#<counter>` where counter is per-ID within one workflow run.
- This allows repeated `step("x", ...)` calls in loops/branches without key collisions.
- On restart, the same code path recomputes the same key sequence, so completed results are correctly reused.
- Bonus auto-ID mode uses callsite identity (`Class#method:line`) + counter.

## Thread Safety During Parallel Execution

- Parallel steps call `context.step(...)` concurrently from multiple threads.
- SQLite operations are performed with retry-on-`SQLITE_BUSY` and WAL mode enabled.
- State transitions use conditional SQL updates (compare-and-set style), preventing double-commit races.
- Lease ownership (`lease_owner`) ensures only the holder can mark completion/failure.

## Zombie Step Handling

`IN_PROGRESS` rows carry a lease expiry timestamp.

- If a worker crashes after side effects but before commit, the row can remain `IN_PROGRESS`.
- On resume, if lease is expired, another runner steals ownership and re-executes the step.
- The onboarding example side effects are idempotent via marker files, so replay is safe.

## Onboarding Example Flow

1. `create-record` (sequential)
2. `provision-laptop` (parallel)
3. `provision-access` (parallel)
4. `send-welcome-email` (sequential)

## Assumptions

- Workflow code is deterministic for a given workflow ID.
- Side effects are expected to be idempotent or guarded with idempotency keys.
- SQLite is sufficient for local/single-host assignment constraints.

## Key Files

- Core: `engine/src/main/java/com/durable/engine/DurableContext.java`
- Store: `engine/src/main/java/com/durable/engine/SQLiteWorkflowStore.java`
- Runner: `engine/src/main/java/com/durable/engine/WorkflowRunner.java`
- Example workflow: `examples/onboarding/src/main/java/com/durable/examples/onboarding/EmployeeOnboardingWorkflow.java`
- CLI app: `app/src/main/java/com/durable/app/App.java`
