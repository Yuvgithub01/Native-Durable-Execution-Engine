package com.durable.engine;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.HashMap;
import java.util.Map;

final class ValueSerializer {
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    private static final Map<String, Class<?>> PRIMITIVE_TYPES = primitiveTypes();

    SerializedValue serialize(Object value) {
        String typeName = (value == null) ? Void.class.getName() : value.getClass().getName();
        try {
            String json = OBJECT_MAPPER.writeValueAsString(value);
            return new SerializedValue(typeName, json);
        } catch (JsonProcessingException ex) {
            throw new IllegalStateException("Unable to serialize step output", ex);
        }
    }

    Object deserialize(String typeName, String jsonValue) {
        if (typeName == null || typeName.isBlank() || Void.class.getName().equals(typeName)) {
            return null;
        }
        if (jsonValue == null) {
            return null;
        }

        Class<?> targetType = resolveType(typeName);
        try {
            return OBJECT_MAPPER.readValue(jsonValue, targetType);
        } catch (Exception ex) {
            throw new IllegalStateException("Unable to deserialize cached step output type=" + typeName, ex);
        }
    }

    private static Class<?> resolveType(String typeName) {
        Class<?> primitiveType = PRIMITIVE_TYPES.get(typeName);
        if (primitiveType != null) {
            return primitiveType;
        }
        try {
            return Class.forName(typeName);
        } catch (ClassNotFoundException ex) {
            throw new IllegalStateException("Cached step output type is not available: " + typeName, ex);
        }
    }

    private static Map<String, Class<?>> primitiveTypes() {
        Map<String, Class<?>> map = new HashMap<>();
        map.put(Boolean.class.getName(), Boolean.class);
        map.put(Byte.class.getName(), Byte.class);
        map.put(Short.class.getName(), Short.class);
        map.put(Integer.class.getName(), Integer.class);
        map.put(Long.class.getName(), Long.class);
        map.put(Float.class.getName(), Float.class);
        map.put(Double.class.getName(), Double.class);
        map.put(Character.class.getName(), Character.class);
        map.put(String.class.getName(), String.class);
        return Map.copyOf(map);
    }
}
