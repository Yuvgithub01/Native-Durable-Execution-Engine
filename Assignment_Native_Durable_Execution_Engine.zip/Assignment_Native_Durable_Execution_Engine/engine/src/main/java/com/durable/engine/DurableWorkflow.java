package com.durable.engine;

@FunctionalInterface
public interface DurableWorkflow<T> {
    T run(DurableContext context) throws Exception;
}
