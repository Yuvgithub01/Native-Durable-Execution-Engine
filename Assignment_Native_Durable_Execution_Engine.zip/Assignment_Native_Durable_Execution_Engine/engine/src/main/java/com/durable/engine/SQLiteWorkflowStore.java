package com.durable.engine;

import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Duration;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

public final class SQLiteWorkflowStore implements WorkflowStore {
    private static final int SQLITE_BUSY_CODE = 5;

    private final String jdbcUrl;
    private final int busyRetries;
    private final long retryBackoffMillis;

    public SQLiteWorkflowStore(Path dbFilePath) {
        this(dbFilePath, 8, Duration.ofMillis(50));
    }

    public SQLiteWorkflowStore(Path dbFilePath, int busyRetries, Duration retryBackoff) {
        this.jdbcUrl = "jdbc:sqlite:" + dbFilePath.toAbsolutePath();
        this.busyRetries = busyRetries;
        this.retryBackoffMillis = retryBackoff.toMillis();
        initializeSchema();
    }

    @Override
    public Optional<StepRecord> findStep(String workflowId, String stepKey) {
        String sql = """
                SELECT workflow_id, step_key, status, output_type, output_json, error_message,
                       lease_owner, lease_expires_at, updated_at
                FROM steps
                WHERE workflow_id = ? AND step_key = ?
                """;

        return withBusyRetry(() -> {
            try (Connection connection = openConnection();
                 PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, workflowId);
                statement.setString(2, stepKey);

                try (ResultSet resultSet = statement.executeQuery()) {
                    if (!resultSet.next()) {
                        return Optional.empty();
                    }
                    return Optional.of(new StepRecord(
                            resultSet.getString("workflow_id"),
                            resultSet.getString("step_key"),
                            StepStatus.valueOf(resultSet.getString("status")),
                            resultSet.getString("output_type"),
                            resultSet.getString("output_json"),
                            resultSet.getString("error_message"),
                            resultSet.getString("lease_owner"),
                            getNullableLong(resultSet, "lease_expires_at"),
                            resultSet.getLong("updated_at")
                    ));
                }
            }
        });
    }

    @Override
    public boolean insertInProgress(String workflowId, String stepKey, String leaseOwner, long leaseExpiresAt, long nowMillis) {
        String sql = """
                INSERT INTO steps(workflow_id, step_key, status, output_type, output_json, error_message,
                                  lease_owner, lease_expires_at, updated_at)
                VALUES(?, ?, 'IN_PROGRESS', NULL, NULL, NULL, ?, ?, ?)
                ON CONFLICT(workflow_id, step_key) DO NOTHING
                """;

        return withBusyRetry(() -> {
            try (Connection connection = openConnection();
                 PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, workflowId);
                statement.setString(2, stepKey);
                statement.setString(3, leaseOwner);
                statement.setLong(4, leaseExpiresAt);
                statement.setLong(5, nowMillis);
                return statement.executeUpdate() == 1;
            }
        });
    }

    @Override
    public boolean stealExpiredInProgress(
            String workflowId,
            String stepKey,
            String newLeaseOwner,
            long newLeaseExpiresAt,
            long nowMillis
    ) {
        String sql = """
                UPDATE steps
                SET lease_owner = ?, lease_expires_at = ?, updated_at = ?, error_message = NULL
                WHERE workflow_id = ? AND step_key = ? AND status = 'IN_PROGRESS' AND lease_expires_at < ?
                """;

        return withBusyRetry(() -> {
            try (Connection connection = openConnection();
                 PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, newLeaseOwner);
                statement.setLong(2, newLeaseExpiresAt);
                statement.setLong(3, nowMillis);
                statement.setString(4, workflowId);
                statement.setString(5, stepKey);
                statement.setLong(6, nowMillis);
                return statement.executeUpdate() == 1;
            }
        });
    }

    @Override
    public boolean claimFailedStep(String workflowId, String stepKey, String leaseOwner, long leaseExpiresAt, long nowMillis) {
        String sql = """
                UPDATE steps
                SET status = 'IN_PROGRESS', lease_owner = ?, lease_expires_at = ?, updated_at = ?, error_message = NULL
                WHERE workflow_id = ? AND step_key = ? AND status = 'FAILED'
                """;

        return withBusyRetry(() -> {
            try (Connection connection = openConnection();
                 PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, leaseOwner);
                statement.setLong(2, leaseExpiresAt);
                statement.setLong(3, nowMillis);
                statement.setString(4, workflowId);
                statement.setString(5, stepKey);
                return statement.executeUpdate() == 1;
            }
        });
    }

    @Override
    public void markCompleted(
            String workflowId,
            String stepKey,
            String leaseOwner,
            String outputType,
            String outputJson,
            long nowMillis
    ) {
        String sql = """
                UPDATE steps
                SET status = 'COMPLETED', output_type = ?, output_json = ?, error_message = NULL,
                    lease_owner = NULL, lease_expires_at = NULL, updated_at = ?
                WHERE workflow_id = ? AND step_key = ? AND status = 'IN_PROGRESS' AND lease_owner = ?
                """;

        withBusyRetry(() -> {
            try (Connection connection = openConnection();
                 PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, outputType);
                statement.setString(2, outputJson);
                statement.setLong(3, nowMillis);
                statement.setString(4, workflowId);
                statement.setString(5, stepKey);
                statement.setString(6, leaseOwner);
                int updatedRows = statement.executeUpdate();
                if (updatedRows != 1) {
                    throw new IllegalStateException("Cannot mark step COMPLETED: workflowId=" + workflowId + ", stepKey=" + stepKey);
                }
                return null;
            }
        });
    }

    @Override
    public void markFailed(String workflowId, String stepKey, String leaseOwner, String errorMessage, long nowMillis) {
        String sql = """
                UPDATE steps
                SET status = 'FAILED', error_message = ?, lease_owner = NULL, lease_expires_at = NULL, updated_at = ?
                WHERE workflow_id = ? AND step_key = ? AND status = 'IN_PROGRESS' AND lease_owner = ?
                """;

        withBusyRetry(() -> {
            try (Connection connection = openConnection();
                 PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, errorMessage);
                statement.setLong(2, nowMillis);
                statement.setString(3, workflowId);
                statement.setString(4, stepKey);
                statement.setString(5, leaseOwner);
                int updatedRows = statement.executeUpdate();
                if (updatedRows != 1) {
                    throw new IllegalStateException("Cannot mark step FAILED: workflowId=" + workflowId + ", stepKey=" + stepKey);
                }
                return null;
            }
        });
    }

    private void initializeSchema() {
        String createTableSql = """
                CREATE TABLE IF NOT EXISTS steps(
                    workflow_id TEXT NOT NULL,
                    step_key TEXT NOT NULL,
                    status TEXT NOT NULL,
                    output_type TEXT,
                    output_json TEXT,
                    error_message TEXT,
                    lease_owner TEXT,
                    lease_expires_at INTEGER,
                    updated_at INTEGER NOT NULL,
                    PRIMARY KEY(workflow_id, step_key)
                )
                """;

        String createStatusIndexSql = """
                CREATE INDEX IF NOT EXISTS idx_steps_workflow_status
                ON steps(workflow_id, status)
                """;

        withBusyRetry(() -> {
            try (Connection connection = openConnection();
                 Statement statement = connection.createStatement()) {
                statement.execute(createTableSql);
                statement.execute(createStatusIndexSql);
                return null;
            }
        });
    }

    private Connection openConnection() throws SQLException {
        Connection connection = DriverManager.getConnection(jdbcUrl);
        try (Statement pragma = connection.createStatement()) {
            pragma.execute("PRAGMA journal_mode=WAL");
            pragma.execute("PRAGMA synchronous=NORMAL");
            pragma.execute("PRAGMA busy_timeout=3000");
        }
        return connection;
    }

    private <T> T withBusyRetry(SqlSupplier<T> supplier) {
        RuntimeException lastFailure = null;
        for (int attempt = 1; attempt <= busyRetries; attempt++) {
            try {
                return supplier.get();
            } catch (SQLException ex) {
                if (!isBusyError(ex)) {
                    throw new IllegalStateException("SQLite operation failed", ex);
                }
                lastFailure = new IllegalStateException("SQLite busy after attempt=" + attempt, ex);
                sleepQuietly(retryBackoffMillis * attempt);
            }
        }
        throw (lastFailure == null)
                ? new IllegalStateException("SQLite operation failed with unknown state")
                : lastFailure;
    }

    private static boolean isBusyError(SQLException ex) {
        if (ex.getErrorCode() == SQLITE_BUSY_CODE) {
            return true;
        }
        String message = ex.getMessage();
        return message != null && message.toUpperCase().contains("SQLITE_BUSY");
    }

    private static void sleepQuietly(long millis) {
        try {
            TimeUnit.MILLISECONDS.sleep(millis);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Interrupted while waiting for SQLITE_BUSY retry", ex);
        }
    }

    private static Long getNullableLong(ResultSet resultSet, String column) throws SQLException {
        long value = resultSet.getLong(column);
        return resultSet.wasNull() ? null : value;
    }

    @Override
    public void close() {
        // Connections are opened per operation and closed immediately.
    }

    @FunctionalInterface
    private interface SqlSupplier<T> {
        T get() throws SQLException;
    }
}
