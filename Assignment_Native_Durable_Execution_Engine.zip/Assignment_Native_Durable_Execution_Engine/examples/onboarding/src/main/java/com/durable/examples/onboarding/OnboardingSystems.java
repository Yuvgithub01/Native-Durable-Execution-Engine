package com.durable.examples.onboarding;

import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public final class OnboardingSystems {
    private final Path stateDirectory;
    private final Path auditLogPath;
    private final Lock auditLock = new ReentrantLock();

    public OnboardingSystems(Path stateDirectory) throws IOException {
        this.stateDirectory = stateDirectory;
        Files.createDirectories(stateDirectory);
        this.auditLogPath = stateDirectory.resolve("operations.log");
        if (!Files.exists(auditLogPath)) {
            Files.createFile(auditLogPath);
        }
    }

    public String createEmployeeRecord(String candidateName, CrashController crashController) {
        String normalized = normalize(candidateName);
        String employeeId = "emp-" + normalized + "-001";
        return idempotentSideEffect("create-record-" + normalized, employeeId, "create-record", crashController);
    }

    public String provisionLaptop(String employeeId, CrashController crashController) {
        String assetId = "laptop-" + employeeId;
        return idempotentSideEffect("provision-laptop-" + employeeId, assetId, "provision-laptop", crashController);
    }

    public String provisionAccess(String employeeId, CrashController crashController) {
        String accessId = "access-" + employeeId;
        return idempotentSideEffect("provision-access-" + employeeId, accessId, "provision-access", crashController);
    }

    public String sendWelcomeEmail(
            String employeeId,
            String laptopAsset,
            String accessGrant,
            CrashController crashController
    ) {
        String emailToken = "welcome-sent-" + employeeId + "-" + laptopAsset + "-" + accessGrant;
        return idempotentSideEffect("send-welcome-email-" + employeeId, emailToken, "send-welcome-email", crashController);
    }

    public long countAuditEvents(String prefix) throws IOException {
        if (!Files.exists(auditLogPath)) {
            return 0L;
        }
        return Files.readAllLines(auditLogPath)
                .stream()
                .filter(line -> line.startsWith(prefix))
                .count();
    }

    public List<String> readAuditLog() throws IOException {
        if (!Files.exists(auditLogPath)) {
            return List.of();
        }
        return Files.readAllLines(auditLogPath);
    }

    private String idempotentSideEffect(
            String operationKey,
            String result,
            String crashStepId,
            CrashController crashController
    ) {
        Path marker = stateDirectory.resolve(operationKey + ".txt");
        if (Files.exists(marker)) {
            return readMarker(marker);
        }

        appendAudit("SIDE_EFFECT:" + operationKey);
        try {
            Files.writeString(marker, result, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
        } catch (FileAlreadyExistsException ignored) {
            return readMarker(marker);
        } catch (IOException ex) {
            throw new IllegalStateException("Failed writing side-effect marker for " + operationKey, ex);
        }

        crashController.maybeCrash(crashStepId);
        return result;
    }

    private String readMarker(Path marker) {
        try {
            return Files.readString(marker);
        } catch (IOException ex) {
            throw new IllegalStateException("Failed reading side-effect marker: " + marker, ex);
        }
    }

    private void appendAudit(String line) {
        auditLock.lock();
        try {
            Files.writeString(
                    auditLogPath,
                    line + System.lineSeparator(),
                    StandardOpenOption.CREATE,
                    StandardOpenOption.APPEND
            );
        } catch (IOException ex) {
            throw new IllegalStateException("Failed appending audit log", ex);
        } finally {
            auditLock.unlock();
        }
    }

    private static String normalize(String value) {
        return value.toLowerCase(Locale.ROOT).trim().replace(' ', '-');
    }
}
